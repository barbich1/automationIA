package utils;

public class AIUtils {
    public static String generarEscenarioConOpenAI(String prompt) {
        // Aquí deberías implementar el uso real del cliente de OpenAI
        return "Escenario generado automáticamente";
    }
}
